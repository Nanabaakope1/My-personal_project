
#!/usr/bin/env bash
set -euo pipefail
REPO="${1:-}"
git init
git add .
git commit -m "Initial import: ClarityHub Enterprise Run Pack" || true
if [ -n "$REPO" ]; then
  if command -v gh >/dev/null; then
    gh repo create "$REPO" --public --source=. --remote=origin --push
  else
    echo "Run: git remote add origin git@github.com:$REPO.git && git branch -M main && git push -u origin main"
  fi
else
  echo "Repo ready locally. To push with GitHub CLI:"
  echo "  gh repo create <owner>/<name> --public --source=. --remote=origin --push"
fi
