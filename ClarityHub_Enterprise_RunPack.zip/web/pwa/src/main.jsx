
import React, {useEffect, useState} from 'react';
import { createRoot } from 'react-dom/client';

function App(){
  const [data,setData] = useState(null);
  useEffect(()=>{
    fetch('http://localhost:8083/insights/weekly').then(r=>r.json()).then(setData).catch(()=>{});
  },[]);
  return <div style={{fontFamily:'Inter,system-ui',padding:24}}>
    <h1>ClarityHub</h1>
    <p>Weekly Insights (from API):</p>
    <pre>{JSON.stringify(data, null, 2) || 'Loading...'}</pre>
  </div>;
}

createRoot(document.getElementById('root')).render(<App/>);
