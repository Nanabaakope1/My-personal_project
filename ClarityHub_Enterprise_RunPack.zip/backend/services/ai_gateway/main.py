import os
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel

app = FastAPI(title="ClarityHub ai_gateway")
app.add_middleware(CORSMiddleware,
    allow_origins=os.getenv("CORS_ORIGINS","*").split(","),
    allow_credentials=True, allow_methods=["*"], allow_headers=["*"])

class GenIn(BaseModel):
    provider: str = "openai"
    text: str

@app.get("/health")
def health(): return {"ok": True, "service": "ai_gateway"}

@app.post("/ai/generate")
def gen(payload: GenIn):
    return {"provider": payload.provider, "output": f"Stub: {payload.text[:200]}..."}
