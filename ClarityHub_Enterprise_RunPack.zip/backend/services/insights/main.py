import os
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

app = FastAPI(title="ClarityHub insights")
app.add_middleware(CORSMiddleware,
    allow_origins=os.getenv("CORS_ORIGINS","*").split(","),
    allow_credentials=True, allow_methods=["*"], allow_headers=["*"])

@app.get("/health")
def health(): return {"ok": True, "service": "insights"}

@app.get("/insights/weekly")
def weekly():
    return {"scores": {"clarity": 72, "resilience": 68, "consistency": 74, "purpose": 70}}
