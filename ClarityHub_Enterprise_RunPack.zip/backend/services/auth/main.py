import os
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel

app = FastAPI(title="ClarityHub auth")
app.add_middleware(CORSMiddleware,
    allow_origins=os.getenv("CORS_ORIGINS","*").split(","),
    allow_credentials=True, allow_methods=["*"], allow_headers=["*"])

class LoginIn(BaseModel):
    email: str
    password: str

@app.get("/health")
def health(): return {"ok": True, "service": "auth"}

@app.post("/auth/login")
def login(payload: LoginIn):
    # NOTE: Stubbed auth for demo; wire to DB/JWT in prod
    return {"ok": True, "token": "dev.jwt.token"}
