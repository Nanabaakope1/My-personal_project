import os
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from typing import Optional

app = FastAPI(title="ClarityHub journal")
app.add_middleware(CORSMiddleware,
    allow_origins=os.getenv("CORS_ORIGINS","*").split(","),
    allow_credentials=True, allow_methods=["*"], allow_headers=["*"])

class ReflectionIn(BaseModel):
    content: str
    sentiment: Optional[str] = None

@app.get("/health")
def health(): return {"ok": True, "service": "journal"}

@app.post("/reflections")
def create_reflection(payload: ReflectionIn):
    # NOTE: stub (add DB insert in prod)
    return {"ok": True, "id": 1, "content": payload.content, "sentiment": payload.sentiment}
