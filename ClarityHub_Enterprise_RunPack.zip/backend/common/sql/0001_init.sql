
CREATE EXTENSION IF NOT EXISTS pgcrypto;

CREATE TABLE IF NOT EXISTS app_user (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  email TEXT UNIQUE NOT NULL,
  password_hash TEXT NOT NULL,
  tier TEXT NOT NULL DEFAULT 'free',
  locale TEXT DEFAULT 'en',
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS reflection (
  id BIGSERIAL PRIMARY KEY,
  user_id UUID,
  content TEXT NOT NULL,
  sentiment TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS insight_weekly (
  id BIGSERIAL PRIMARY KEY,
  user_id UUID,
  week_start DATE NOT NULL DEFAULT CURRENT_DATE,
  clarity SMALLINT, resilience SMALLINT, consistency SMALLINT, purpose SMALLINT,
  summary TEXT
);
