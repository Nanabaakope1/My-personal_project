
# ClarityHub — Enterprise Run Pack

This is a runnable, developer-friendly pack: start Postgres + Redis and 4 FastAPI microservices with one command.

## Quick start
```bash
cp security/.env.example security/.env
docker compose -f infra/docker/docker-compose.dev.yml up --build
```

### Initialize DB schema (one-time)
Open a second terminal:
```bash
docker exec -i clarityhub-db psql -U clarity -d claritydb < backend/common/sql/0001_init.sql
```

### Try the APIs
- Auth:      http://localhost:8082/health
- AI:        http://localhost:8081/health
- Insights:  http://localhost:8083/insights/weekly
- Journal:   http://localhost:8084/reflections  (POST)

### Run the demo PWA (optional)
```bash
cd web/pwa && npm i && npm run dev
# open http://localhost:5173  (it fetches /insights/weekly)
```

## Push to GitHub
```bash
bash scripts/bootstrap_repo.sh your-username/clarityhub
```
