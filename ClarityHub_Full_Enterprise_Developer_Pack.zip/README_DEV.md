Ports: auth 8082, ai 8081, insights 8083, journal 8084.
