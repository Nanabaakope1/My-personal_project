Do it now prompt.
