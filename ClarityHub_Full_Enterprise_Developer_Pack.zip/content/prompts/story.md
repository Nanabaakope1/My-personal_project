Story prompt here.
