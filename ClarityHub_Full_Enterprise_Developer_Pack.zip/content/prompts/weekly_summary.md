Weekly summary prompt.
