import os, time, json, requests, socket, threading

API = os.getenv('API_ENDPOINT', 'http://localhost:3000/api/cycles/ingest')
WATCH_DIR = os.getenv('WATCH_DIR', '/var/sterilevision/incoming')
TCP_PORT = int(os.getenv('TCP_PORT', '9001'))

def parse_payload(raw):
    txt = raw.decode() if isinstance(raw, bytes) else raw
    payload = {
        'source': 'steam' if 'autoclave' in txt.lower() else ('sterrad' if 'sterrad' in txt.lower() else ('washer' if 'wash' in txt.lower() else 'ultrasonic')),
        'loader_station': 'AutoDetect',
        'metrics': { 'program': 'Auto', 'pass': 'fail' not in txt.lower() }
    }
    return payload

def post_payload(payload):
    try:
        r = requests.post(API, json=payload, timeout=10)
        print('POST', payload['source'], r.status_code)
    except Exception as e:
        print('Error posting', e)

def watch_folder():
    seen = set()
    while True:
        for f in os.listdir(WATCH_DIR):
            path = os.path.join(WATCH_DIR, f)
            if f not in seen and os.path.isfile(path):
                with open(path, 'r') as fp: raw = fp.read()
                payload = parse_payload(raw)
                post_payload(payload)
                seen.add(f)
        time.sleep(5)

def tcp_listener():
    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    s.bind(('0.0.0.0', TCP_PORT))
    s.listen(5)
    print('Listening on TCP', TCP_PORT)
    while True:
        conn, addr = s.accept()
        data = conn.recv(8192)
        if data:
            payload = parse_payload(data)
            post_payload(payload)
        conn.close()

if __name__ == '__main__':
    threading.Thread(target=watch_folder, daemon=True).start()
    tcp_listener()
