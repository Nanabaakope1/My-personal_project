ClarityHub — GitHub‑Ready Enterprise Monorepo
Quick start inside.
