#!/usr/bin/env bash
set -e
git init && git add . && git commit -m 'init' || true
