import os, time, json, socket, threading, requests, pathlib
API=os.getenv('API_ENDPOINT','http://localhost:3000/api/cycles/ingest')
WATCH_DIR=os.getenv('WATCH_DIR','/data/incoming')
TCP_PORT=int(os.getenv('TCP_PORT','9001'))

def parse_payload(raw:str):
 txt=raw.lower(); src='ultrasonic'
 if 'autoclave' in txt or 'steam' in txt: src='steam'
 elif 'sterrad' in txt: src='sterrad'
 elif 'wash' in txt or 'washer' in txt: src='washer'
 return {"source":src,"loader_station":"unknown","metrics":{"raw":raw}}

def tcp_server():
 s=socket.socket(socket.AF_INET,socket.SOCK_STREAM); s.bind(('0.0.0.0',TCP_PORT)); s.listen(5)
 while True:
  conn,addr=s.accept(); data=conn.recv(65535).decode('utf-8','ignore')
  if data:
   try: requests.post(API,json=parse_payload(data),timeout=5)
   except Exception as e: print('post failed',e)
  conn.close()

def dir_watcher():
 pathlib.Path(WATCH_DIR).mkdir(parents=True, exist_ok=True)
 seen=set()
 while True:
  for p in pathlib.Path(WATCH_DIR).glob('*.txt'):
   if p not in seen:
    raw=p.read_text()
    try: requests.post(API,json=parse_payload(raw),timeout=5)
    except Exception as e: print('post failed',e)
    seen.add(p)
  time.sleep(2)

if __name__=='__main__':
 threading.Thread(target=tcp_server,daemon=True).start()
 dir_watcher()
