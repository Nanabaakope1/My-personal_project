module.exports = { experimental:{ appDir:true } };
