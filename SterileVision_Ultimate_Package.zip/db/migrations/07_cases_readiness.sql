
CREATE TABLE IF NOT EXISTS cases(case_id BIGSERIAL PRIMARY KEY, patient TEXT, surgeon TEXT, room TEXT, scheduled_at TIMESTAMPTZ);
CREATE TABLE IF NOT EXISTS case_items(case_id BIGINT REFERENCES cases(case_id) ON DELETE CASCADE, tray_id BIGINT REFERENCES trays(tray_id), PRIMARY KEY(case_id, tray_id));
