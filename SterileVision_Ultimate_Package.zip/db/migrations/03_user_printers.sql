
CREATE TABLE IF NOT EXISTS user_printer_defaults (user_id BIGINT NOT NULL REFERENCES users(user_id) ON DELETE CASCADE, label_printer_id BIGINT REFERENCES printers(printer_id) ON DELETE SET NULL, laser_printer_id BIGINT REFERENCES printers(printer_id) ON DELETE SET NULL, updated_at TIMESTAMPTZ DEFAULT now(), PRIMARY KEY(user_id));
