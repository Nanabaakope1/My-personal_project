
CREATE TABLE IF NOT EXISTS policy_rules(rule_id BIGSERIAL PRIMARY KEY, name TEXT, scope TEXT, json JSONB, enabled BOOLEAN DEFAULT true);
