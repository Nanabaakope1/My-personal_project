
CREATE TABLE IF NOT EXISTS departments(department_id BIGSERIAL PRIMARY KEY, name TEXT UNIQUE NOT NULL);
INSERT INTO departments(name) VALUES ('Decontamination'),('Assembly'),('Sterilization'),('OR Core'),('Clinic') ON CONFLICT DO NOTHING;
CREATE TABLE IF NOT EXISTS department_printer_defaults (department_id BIGINT REFERENCES departments(department_id) ON DELETE CASCADE, label_printer_id BIGINT REFERENCES printers(printer_id) ON DELETE SET NULL, laser_printer_id BIGINT REFERENCES printers(printer_id) ON DELETE SET NULL, updated_at TIMESTAMPTZ DEFAULT now(), PRIMARY KEY(department_id));
