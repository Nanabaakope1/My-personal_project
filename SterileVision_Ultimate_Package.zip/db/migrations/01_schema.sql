
CREATE TABLE IF NOT EXISTS users(user_id BIGSERIAL PRIMARY KEY, name TEXT, email TEXT UNIQUE, role TEXT DEFAULT 'Tech');
CREATE TABLE IF NOT EXISTS trays(tray_id BIGSERIAL PRIMARY KEY, tray_name TEXT NOT NULL, location TEXT, fifo_tag TEXT, cycle_hint TEXT);
CREATE TABLE IF NOT EXISTS instruments(instrument_id BIGSERIAL PRIMARY KEY, name TEXT, img TEXT, ifu TEXT);
CREATE TABLE IF NOT EXISTS tray_items(tray_id BIGINT REFERENCES trays(tray_id) ON DELETE CASCADE, instrument_id BIGINT REFERENCES instruments(instrument_id) ON DELETE CASCADE, required_qty INT DEFAULT 1, PRIMARY KEY(tray_id, instrument_id));
CREATE TABLE IF NOT EXISTS assembly_sessions(session_id BIGSERIAL PRIMARY KEY, tray_id BIGINT REFERENCES trays(tray_id), user_id BIGINT REFERENCES users(user_id), status TEXT DEFAULT 'Open', started_at TIMESTAMPTZ DEFAULT now(), completed_at TIMESTAMPTZ);
CREATE TABLE IF NOT EXISTS assembly_items(session_id BIGINT REFERENCES assembly_sessions(session_id) ON DELETE CASCADE, instrument_id BIGINT REFERENCES instruments(instrument_id), included_qty INT DEFAULT 0, required_qty INT DEFAULT 1, PRIMARY KEY(session_id, instrument_id));
