
CREATE TABLE IF NOT EXISTS workstations (workstation_id BIGSERIAL PRIMARY KEY, name TEXT UNIQUE NOT NULL, department_id BIGINT REFERENCES departments(department_id) ON DELETE SET NULL, ip_address TEXT, mac_address TEXT, description TEXT, updated_at TIMESTAMPTZ DEFAULT now());
