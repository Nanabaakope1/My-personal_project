
CREATE TABLE IF NOT EXISTS loads(load_id BIGSERIAL PRIMARY KEY, source TEXT, loader_station TEXT, started_at TIMESTAMPTZ DEFAULT now(), finished_at TIMESTAMPTZ, metrics JSONB);
CREATE TABLE IF NOT EXISTS load_items(load_id BIGINT REFERENCES loads(load_id) ON DELETE CASCADE, tray_id BIGINT REFERENCES trays(tray_id) ON DELETE SET NULL);
CREATE TABLE IF NOT EXISTS bi_tests(bi_id BIGSERIAL PRIMARY KEY, load_id BIGINT REFERENCES loads(load_id), lot TEXT, result TEXT, tested_at TIMESTAMPTZ);
CREATE TABLE IF NOT EXISTS ci_indicators(ci_id BIGSERIAL PRIMARY KEY, load_id BIGINT REFERENCES loads(load_id), result TEXT, checked_at TIMESTAMPTZ);
