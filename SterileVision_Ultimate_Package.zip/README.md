# Sterile Vision — Ultimate Package

An enterprise Sterile Processing platform (web + API) with printing (ZPL/PDF), cases & cycle ingest, and Dockerized stack.

## Quick Start (Docker, local)
```bash
cp .env.example .env
docker compose up --build
# open http://localhost:3000
```
Then:
- Go to **/tech/quick-tools**: pick printers, enter tray id, **Print Now**.
- Go to **/mobile/assembly/quick**: start session, add instruments, **Complete** → auto-prints label & countsheet.
- Print jobs visible via **/api/prints/jobs** JSON (UI page can be added easily).

## Project Layout
- `app/` — Next.js App Router (API + UI)
- `db/migrations/` — PostgreSQL schema & migrations
- `collector/` — Python microservice to ingest cycles (TCP or folder watch)
- `docker-compose.yml` — one-command local stack
- `.github/workflows/` — GitHub Actions (build + optional Docker publish)

## Minimum Requirements
- Docker & Docker Compose
- 4GB RAM, 5GB disk
- Network access to printers (TCP 9100 for Zebra; CUPS/LPR for laser)

## Next Steps
- Add real trays/instruments (DB seeds or upload tool)
- Connect hospital printers (set defaults per user/department)
- Connect OR schedule feeder to `/api/cases/ingest`
- Point device exports/TCP to the **collector** (port 9001 or `incoming/` dir)
