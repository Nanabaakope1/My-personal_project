# Import to Lovable.dev, Cursor, and Replit

## Lovable.dev
1. Click **New Project → Import from GitHub**.
2. Point to your repo (or upload this ZIP directly).
3. Use the built-in builder to scaffold UI screens (pages already exist).

## Cursor
1. Open Cursor → **Open Folder** (this project) or **Clone GitHub Repo**.
2. Use Cursor's AI to refactor or generate additional pages.

## Replit
1. Create Repl → **Import from GitHub** (Node.js).
2. Add a Postgres add-on or run Docker if available; otherwise set `DATABASE_URL` to external Postgres.
