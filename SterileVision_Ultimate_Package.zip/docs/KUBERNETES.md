# Kubernetes (high level)

- Build and push image (via GitHub Actions or local `docker build` + `docker push`).
- Create a Postgres instance or use a managed DB (RDS/Cloud SQL).
- Deployment:
  - `Deployment` for the app with env vars.
  - `Service` `LoadBalancer` for HTTP.
  - `PersistentVolume` for `/data/exports`.
- Configure secrets for `DATABASE_URL` and `APP_URL`.
