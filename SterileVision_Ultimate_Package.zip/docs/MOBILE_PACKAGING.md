# Mobile App Packaging (Capacitor PWA → Android/iOS)

This project is a fast PWA. To publish as native shells:
1. Install Capacitor in this repo (local machine):
   ```bash
   npm i @capacitor/core @capacitor/cli
   npx cap init "SterileVision" "com.sterile.vision"
   npm run build
   npx cap add android
   npx cap add ios
   npx cap copy
   npx cap open android   # open in Android Studio
   npx cap open ios       # open in Xcode (on macOS)
   ```
2. Configure camera/scan permissions in native manifests if needed.
3. Build & sign from Android Studio / Xcode.
