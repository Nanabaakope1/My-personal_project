# GitHub Usage

## Create and Push
```bash
git init
git add .
git commit -m "Initial commit — Sterile Vision"
git branch -M main
git remote add origin https://github.com/<you>/sterile-vision.git
git push -u origin main
```

## GitHub Actions
- `.github/workflows/build.yml` — CI build & migration smoke test.
- `.github/workflows/docker-publish.yml` — publish image to Docker Hub.
Add secrets in GitHub → Settings → Secrets → Actions:
- `DOCKERHUB_USERNAME`
- `DOCKERHUB_TOKEN`
