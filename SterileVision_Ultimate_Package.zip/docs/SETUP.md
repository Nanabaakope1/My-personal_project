# Setup & Configuration

## 1) Environment
Copy `.env.example` to `.env` and adjust as needed:
```
APP_URL=http://localhost:3000
DATABASE_URL=postgres://sv:svpass@db:5432/sterilevision
PRINT_EXPORT_DIR=/data/exports
SNMP_COMMUNITY=public
NODE_ENV=production
```

## 2) Start
```
docker compose up --build
```

## 3) Printers
Create printers in the `printers` table (via SQL client or future UI):
```sql
INSERT INTO printers(name,kind,protocol,host,port,is_default) 
VALUES ('Zebra-SPD-01','label','raw9100','192.168.10.40',9100,true);

INSERT INTO printers(name,kind,protocol,queue,is_default) 
VALUES ('Laser-A4','laser','lpr','SPD-A4',true);
```

## 4) Try it
- **Label:** POST `/api/print/zpl` with `{ "tray": 1 }`
- **PDF countsheet:** POST `/api/print/pdf` with `{ "tray": 1, "print": true }`
- **Assembly:** use `/mobile/assembly/quick` to complete a session and trigger auto-print.

## 5) Data Model (short)
- `trays`, `instruments`, `tray_items`
- `assembly_sessions`, `assembly_items`
- `printers`, `print_jobs`
- `departments`, `department_printer_defaults`
- `workstations`
- `cases`, `case_items`
- `loads`, `load_items`, `bi_tests`, `ci_indicators`
- `policy_rules`
```sql
-- Add a tray + instruments example
INSERT INTO trays(tray_name, cycle_hint) VALUES ('Basic Tray','Steam') RETURNING tray_id;
INSERT INTO instruments(name, img, ifu) VALUES ('Scissor', null, null), ('Forceps', null, null);
INSERT INTO tray_items(tray_id, instrument_id, required_qty) SELECT $TRAY, instrument_id, 2 FROM instruments WHERE name='Scissor';
INSERT INTO tray_items(tray_id, instrument_id, required_qty) SELECT $TRAY, instrument_id, 4 FROM instruments WHERE name='Forceps';
```

## 6) OR Cases
POST to `/api/cases/ingest` with:
```json
{
  "cases":[
    {"patient":"ID123","surgeon":"Dr X","room":"OR-2","scheduled_at":"2025-11-10T14:00:00Z","trays":[1]}
  ]
}
```

## 7) Device Cycles Collector
- TCP: send text payload to port **9001** (collector normalizes & posts).
- Folder: drop a `.txt` file into `incoming/` (mounted to `/data/incoming`).

## 8) Security
- The sample runs open for local testing. In prod, put behind HTTPS + reverse proxy.
- Add auth/SSO (Keycloak-compatible endpoints or built-in auth layer).
