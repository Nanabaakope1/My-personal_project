-- Demo data to click around
INSERT INTO users(name,email,role) VALUES ('Tech One','tech1@example.com','Tech') ON CONFLICT DO NOTHING;
INSERT INTO trays(tray_name,cycle_hint) VALUES ('Demo Basic Tray','Steam') RETURNING tray_id;
WITH ins AS (
  INSERT INTO instruments(name) VALUES ('Scissor'),('Forceps') RETURNING instrument_id, name
)
INSERT INTO tray_items(tray_id, instrument_id, required_qty)
SELECT (SELECT tray_id FROM trays WHERE tray_name='Demo Basic Tray'),
       instrument_id,
       CASE WHEN name='Scissor' THEN 2 ELSE 4 END
FROM ins;
