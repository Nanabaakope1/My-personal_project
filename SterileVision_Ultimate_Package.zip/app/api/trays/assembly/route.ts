import { NextResponse } from 'next/server'
import { pool } from '../../utils/db'
export async function GET(req:Request){ const url=new URL(req.url); const tray=Number(url.searchParams.get('tray')||'0'); const q=await pool.query(`SELECT ti.instrument_id as id, i.name, i.img, i.ifu, ti.required_qty as required, 0 as included, ti.required_qty as missing FROM tray_items ti JOIN instruments i ON i.instrument_id=ti.instrument_id WHERE ti.tray_id=$1`,[tray]); return NextResponse.json({ items: q.rows }) }
