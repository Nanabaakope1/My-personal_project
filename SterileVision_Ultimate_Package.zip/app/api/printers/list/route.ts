import { NextResponse } from 'next/server'
import { pool } from '../../utils/db'
export async function GET(){ const q=await pool.query(`SELECT printer_id,name,kind,protocol,host,port,queue,is_default FROM printers ORDER BY kind,name`); return NextResponse.json({ items: q.rows }) }
