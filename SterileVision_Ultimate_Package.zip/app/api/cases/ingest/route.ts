import { NextResponse } from 'next/server'
import { pool } from '../../utils/db'
export async function POST(req:Request){ const { cases=[] }=await req.json(); for(const c of cases){ const r=await pool.query('INSERT INTO cases(patient,surgeon,room,scheduled_at) VALUES ($1,$2,$3,$4) RETURNING case_id',[c.patient,c.surgeon,c.room,c.scheduled_at]); for(const t of (c.trays||[])){ await pool.query('INSERT INTO case_items(case_id,tray_id) VALUES ($1,$2) ON CONFLICT DO NOTHING',[r.rows[0].case_id,t]) } } return NextResponse.json({ ok:true }) }
