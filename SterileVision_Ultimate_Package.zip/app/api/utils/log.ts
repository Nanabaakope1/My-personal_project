export function logEvent(evt:string,data:any){try{console.log(JSON.stringify({evt,ts:new Date().toISOString(),...data}))}catch{}}
