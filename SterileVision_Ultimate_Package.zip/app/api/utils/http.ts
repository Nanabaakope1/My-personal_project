export function noCache(){return{'Cache-Control':'no-store, no-cache, must-revalidate, proxy-revalidate'}}
export function shortCache(){return{'Cache-Control':'public, max-age=60'}}
