import { NextResponse } from 'next/server'
import { pool } from '../../utils/db'
export async function POST(req:Request){ const body=await req.json(); const r=await pool.query('INSERT INTO loads(source,loader_station,metrics,finished_at) VALUES ($1,$2,$3,now()) RETURNING load_id',[body.source||'unknown',body.loader_station||null,body.metrics||{}]); return NextResponse.json({ ok:true, load_id:r.rows[0].load_id }) }
