import { NextResponse } from 'next/server'
import { pool } from '../../utils/db'
export async function GET(){ const q=await pool.query(`SELECT j.job_id,j.tray_id,j.type,j.status,j.updated_at,p.name AS printer_name FROM print_jobs j LEFT JOIN printers p ON p.printer_id=j.printer_id ORDER BY j.updated_at DESC LIMIT 200`); return NextResponse.json({ items: q.rows }) }
