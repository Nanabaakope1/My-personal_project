import { NextResponse } from 'next/server'
export async function GET(req:Request){ const url=new URL(req.url); const tray=url.searchParams.get('tray')||'0'; const role=url.searchParams.get('role')||'Tech'; return NextResponse.json({fields:{title:`Tray ${tray}`,barcode:`SV-${tray}`,fifo:'A1',due:null,cycle:'Steam'},role}) }
