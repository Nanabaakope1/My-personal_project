import { NextResponse } from 'next/server'
export async function GET(req:Request){ const url=new URL(req.url); const tray=Number(url.searchParams.get('tray')||'0'); return NextResponse.json({meta:{tray_id:tray,tray_name:`Tray ${tray}`,next_needed:null,cycle_hint:'Steam'},groups:[{name:'A',items:[{name:'Scissor',required:2},{name:'Forceps',required:4}]}]}) }
